#ifndef __BLAKE512_CONFIG_H__
#define __BLAKE512_CONFIG_H__

#define AVOID_BRANCHING 1
//#define HAVE_XOP 1

#endif

